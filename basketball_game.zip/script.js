
const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");

canvas.width = 800;
canvas.height = 600;

// Game variables
const player1 = { x: 100, y: 500, width: 20, height: 20, color: "blue", score: 0 };
const player2 = { x: 700, y: 500, width: 20, height: 20, color: "green", score: 0 };
const ball = { x: 400, y: 300, radius: 10, dx: 2, dy: 2, color: "orange" };
const hoop = { x: 350, y: 100, width: 100, height: 10 };
let currentEvent = "None";

// Key states
const keys = {};

// Update scores
function updateScore(player) {
  if (player === "player1") {
    player1.score += 2;
    document.getElementById("score1").textContent = player1.score;
  } else if (player === "player2") {
    player2.score += 2;
    document.getElementById("score2").textContent = player2.score;
  }
}

// Draw functions
function drawPlayer(player) {
  ctx.fillStyle = player.color;
  ctx.fillRect(player.x, player.y, player.width, player.height);
}

function drawBall() {
  ctx.beginPath();
  ctx.arc(ball.x, ball.y, ball.radius, 0, Math.PI * 2);
  ctx.fillStyle = ball.color;
  ctx.fill();
  ctx.closePath();
}

function drawHoop() {
  ctx.fillStyle = "red";
  ctx.fillRect(hoop.x, hoop.y, hoop.width, hoop.height);
}

// Handle events
function triggerEvent() {
  const events = ["Double Points", "Time Challenge", "Move Hoop"];
  currentEvent = events[Math.floor(Math.random() * events.length)];
  document.getElementById("event").textContent = `Event: ${currentEvent}`;

  if (currentEvent === "Move Hoop") {
    hoop.x = Math.random() * (canvas.width - hoop.width);
  }
}

// Game loop
function gameLoop() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  // Draw everything
  drawPlayer(player1);
  drawPlayer(player2);
  drawBall();
  drawHoop();

  // Ball movement
  ball.x += ball.dx;
  ball.y += ball.dy;

  if (ball.x + ball.radius > canvas.width || ball.x - ball.radius < 0) ball.dx *= -1;
  if (ball.y + ball.radius > canvas.height || ball.y - ball.radius < 0) ball.dy *= -1;

  // Check for scoring
  if (
    ball.x > hoop.x &&
    ball.x < hoop.x + hoop.width &&
    ball.y > hoop.y &&
    ball.y < hoop.y + hoop.height
  ) {
    updateScore("player1"); // Simplify: Always Player 1 for now
    ball.x = 400;
    ball.y = 300;
  }

  requestAnimationFrame(gameLoop);
}

// Event timer
setInterval(triggerEvent, 10000);

// Key listeners
document.addEventListener("keydown", (e) => (keys[e.key] = true));
document.addEventListener("keyup", (e) => (keys[e.key] = false));

gameLoop();
